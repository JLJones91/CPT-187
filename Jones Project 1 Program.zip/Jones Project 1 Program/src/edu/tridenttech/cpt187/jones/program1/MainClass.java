//FILE: MainClass.java
//PROG: Jamie Jones
//PURP: Simulate a real bank savings account using the class SavingsAccount. 

package edu.tridenttech.cpt187.jones.program1;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		SavingsAccount myAccount = new SavingsAccount();
		String	userName = "";
		String	acctNumb = "";
		double	currentBalance;
		double	currentRate;
		double	addAmount;
		double	removeAmount;
		
		System.out.println("What is your first name?");
		userName = input.nextLine();		
		acctNumb = myAccount.getAccountNumber();
		currentBalance = myAccount.getBalance();
		currentRate = myAccount.getRate();
		
		System.out.println("Thank you " + userName + ". How much would you like to "
				+ "add to your account?");
		addAmount = input.nextDouble();
		myAccount.addToBalance(addAmount);
		
		System.out.println("Thank you " + userName + ". How much would you like to "
				+ "remove from your account?");
		removeAmount = input.nextDouble();
		myAccount.withdrawFromBalance(removeAmount);
		
		System.out.println(userName + ", for Account Number: " + acctNumb);
		System.out.println("With a starting balance of " + currentBalance);
		System.out.println("You added $" + addAmount + " to your account,");
		System.out.println("and removed $" + removeAmount + ".");
		System.out.println("The new balance after deposit is $" + myAccount.getBalance());
		System.out.println("At an interest rate of " + currentRate + "%.");
	
		input.close();
	}
}//END MainClass
