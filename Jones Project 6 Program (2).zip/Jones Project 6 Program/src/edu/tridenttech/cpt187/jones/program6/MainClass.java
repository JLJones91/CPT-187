//FILENAME: MainClass.java
//PROG: Jamie Jones
//Purpose: Load and Test Arrays
package edu.tridenttech.cpt187.jones.program6;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		InventoryData newArray = new InventoryData();
		String fileName = "inventoryPricing.dat";
		int runProgram = ' ';
		int target;
		
		newArray.loadArrays(fileName);

		System.out.println("Press any key to enter part number or press Q to quit." );
		runProgram = input.next().charAt(0);
		runProgram = Character.toUpperCase(runProgram);
		
		while(runProgram != 'Q')
		{
			System.out.println("Please enter Part Number:");
			target = input.nextInt();
			
			//Run Seq Search
			newArray.seqSearch(target);
			//Get Seq Price
			if(newArray.getSeqPrice() >= 0)
			{
				System.out.println("Sequential found Part Number: " + target + ". Item Price is: $" + newArray.getSeqPrice());
			}
			else
			{
				System.out.println("Sequential Could Not Find Part Number: " + target + ".");
			}
			//Run Bin Search
			newArray.binSearch(target);
			//Get Bin Price
			if(newArray.getBinPrice() == -1)
			{
				System.out.println("Binary Could Not Find Part Number: " + target + ".");
			}
			else
			{
				System.out.println("Binary found Part Number: " + target + ". Item Price is: $" + newArray.getBinPrice());
			}
						
			System.out.println("Press Q to quit, or any key to continue entering Part Numbers." );
			runProgram = input.next().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
		}
		System.out.println("Have a nice Day!");
			
		input.close();
	}
}//END MainClass
