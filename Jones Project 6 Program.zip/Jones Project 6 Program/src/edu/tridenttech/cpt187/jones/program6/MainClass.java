//FILENAME: MainClass.java
//PROG: Jamie Jones
//Purpose: Load and Test Arrays
package edu.tridenttech.cpt187.jones.program6;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		InventoryData newArray = new InventoryData();
		String fileName = "inventoryPricing.dat";
		int runProgram = ' ';
		int target;
		
		newArray.loadArrays(fileName);

		System.out.println("Press any key to enter part number or press Q to quit." );
		runProgram = input.next().charAt(0);
		runProgram = Character.toUpperCase(runProgram);
		
		while(runProgram != 'Q')
		{
			System.out.println("Please enter Part Number:");
			target = input.nextInt();
			
			newArray.seqSearch(target);
			newArray.displaySeqPrice(target);
			
			newArray.binSearch(target);
			newArray.displayBinPrice(target);
			
			System.out.println("Press Q to quit, or any key to continue entering Part Numbers." );
			runProgram = input.next().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
		}
		System.out.println("Have a nice Day!");
			
		input.close();
	}
}//END MainClass
