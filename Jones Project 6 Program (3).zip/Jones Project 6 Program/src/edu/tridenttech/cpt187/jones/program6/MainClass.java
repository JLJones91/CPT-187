//FILENAME: MainClass.java
//PROG: Jamie Jones
//Purpose: Load and Test Arrays
package edu.tridenttech.cpt187.jones.program6;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		InventoryData newArray = new InventoryData();
		String fileName = "inventoryPricing.dat";
		int runProgram = ' ';
		int target;
		
		//Load Arrays
		newArray.loadArrays(fileName);
		
		//Customer Input
		System.out.println("Press any key to enter part number or press Q to quit." );
		runProgram = input.next().charAt(0);
		runProgram = Character.toUpperCase(runProgram);
		
		while(runProgram != 'Q')
		{
			System.out.println("Please enter Part Number:");
			target = input.nextInt();
			
			//Run seqSearch
			int seqIndex = newArray.seqSearch(target);
			double seqPrice = newArray.getPrice(seqIndex);
						
			//Get seqPrice
			if(newArray.getPrice(seqIndex) >= 0)
			{
				System.out.println("Sequential found Part Number: " + target + ". Item Price is: $" + seqPrice);
			}
			else
			{
				System.out.println("Sequential Could Not Find Part Number: " + target + ".");
			}
			
			//Run binSearch
			int binIndex = newArray.binSearch(target);
			double binPrice = newArray.getPrice(binIndex);
			
			//Get binPrice
			if(newArray.getPrice(binIndex) == -1)
			{
				System.out.println("Binary Could Not Find Part Number: " + target + ".");
			}
			else
			{
				System.out.println("Binary found Part Number: " + target + ". Item Price is: $" + binPrice);
			}
						
			System.out.println("Press Q to quit, or any key to continue entering Part Numbers." );
			runProgram = input.next().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
		}//END while loop
		System.out.println("Have a nice Day!");
			
		input.close();
	}
}//END MainClass
