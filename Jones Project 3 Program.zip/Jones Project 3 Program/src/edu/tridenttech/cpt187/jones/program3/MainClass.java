//FILE: MainClass.java
//PROG: Jamie Jones
//PURP: Simualte an elevator moving up and down, 
		//load and unload passengers

package edu.tridenttech.cpt187.jones.program3;

import java.util.Scanner;

public class MainClass 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		Elevator myRide = new Elevator(18, 1, 99, 1, 0);
		int	maxRiders;		//Max Riders of Elevator
		int curntFloor;		//Current Floor Elevator is on
		int	highestFloor; 	//Highest Floor Elevator can go
		int lowestFloor;	//Lowest Floor Elevator can go
		int	curntPass;	 	//Number of passengers on elevator
		int numbOn;			//Number of people getting on
		int numbOff;		//Number of people getting off
		int	destFloor;		//Destination floor
		
		curntFloor = myRide.getCurrentFloor();
		maxRiders = myRide.getMaxCapacity();
		curntPass = myRide.getNumOnBoard();
		System.out.println("You are on floor #" + curntFloor +".");
		
		//# of Passengers getting on
		numbOn = 15; 
		myRide.loadElevator(numbOn, maxRiders, curntPass);
		curntPass += numbOn;
		
		destFloor = 5; //Set destination Floor
		//Move Elevator Up
		highestFloor = myRide.getMaxFloor();
		lowestFloor = myRide.getMinFloor();
		curntFloor = myRide.getCurrentFloor();
		
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		curntFloor = destFloor;
		
		//# of Pass getting off Elevator
		numbOff = 10; 
		myRide.unLoadElevator(numbOff, curntPass);
		curntPass -= numbOff;
		while (curntPass < 0)
		{
			curntPass = 0;
		}
		System.out.println("Remaining Passengers: " + curntPass);
		
		//# of Pass getting on
		numbOn = 5; 
		myRide.loadElevator(numbOn, maxRiders, curntPass);
		curntPass += numbOn;
		
		destFloor = 2; //Set destination Floor
		//Move Elevator Down
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		curntFloor = destFloor;
		
		//# of Pass getting off Elevator
		numbOff = 15; 
		myRide.unLoadElevator(numbOff, curntPass);
		curntPass -= numbOff;
		while (curntPass < 0)
		{
			curntPass = 0;
		}
		System.out.println("Remaining Passengers: " + curntPass);
	
		//# of Pass getting on
		numbOn = 25; 
		myRide.loadElevator(numbOn, maxRiders, curntPass);
		curntPass += numbOn;
		while (curntPass > maxRiders)
		{
			curntPass = maxRiders;
		}
		
		//Move Elevator too high
		destFloor = 150; //Set destination Floor
		//Move Elevator Up
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		
		//Move Elevator too low
		destFloor = -5; //Set destination Floor
		//Move Elevator Down
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		
		//Move Elevator same floor
		destFloor=2; //Set destination Floor
		//Move Elevator Up
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		
		//Move Elevator
		destFloor=50; //Set destination Floor
		//Move Elevator Up
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);
		curntFloor = destFloor;
		
		//# of Pass getting off Elevator
		numbOff = 15; 
		myRide.unLoadElevator(numbOff, curntPass);
		curntPass -= numbOff;
		while (curntPass < 0)
		{
			curntPass = 0;
		}
		System.out.println("Remaining Passengers: " + curntPass);
	
		//# of Pass getting on
		numbOn = 5; 
		myRide.loadElevator(numbOn, maxRiders, curntPass);
		curntPass += numbOn;
		while (curntPass > maxRiders)
		{
			curntPass = maxRiders;
		}
		
		//Move Elevator
		destFloor = 99; //Set destination Floor
		//Move Elevator Down
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		curntFloor = destFloor;
		
		//# of Pass getting off Elevator
		numbOff = 3; 
		myRide.unLoadElevator(numbOff, curntPass);
		curntPass -= numbOff;
		while (curntPass < 0)
		{
			curntPass = 0;
		}
		System.out.println("Remaining Passengers: " + curntPass);
		
		//# of Pass getting on
		numbOn = 13; 
		myRide.loadElevator(numbOn, maxRiders, curntPass);
		curntPass += numbOn;
		while (curntPass > maxRiders)
		{
			curntPass = maxRiders;
		}
		
		//Move Elevator
		destFloor = 1; //Set destination Floor
		//Move Elevator Down
		moveElevator (highestFloor, lowestFloor, destFloor, curntFloor);		
		curntFloor = destFloor;
		
		//# of Pass getting off Elevator
		numbOff = 18; 
		myRide.unLoadElevator(numbOff, curntPass);
		curntPass -= numbOff;
		while (curntPass < 0)
		{
			curntPass = 0;
		}
		System.out.println("Remaining Passengers: " + curntPass);
				
		input.close();
		
		
	}//End class
	
	//Begin moveElevator
	static void moveElevator (int highestFloor, int lowestFloor, int destFloor, int curntFloor)
		{
		if (highestFloor < destFloor)
		{
			System.out.println("I'm sorry you cannot go there!");
			System.out.println("The highest floor in this building is " + highestFloor + ".");
		
		}
	
		else if(lowestFloor > destFloor)		
		{
			System.out.println("I'm sorry you cannot go there.");
			System.out.println("The lowest floor in this building is " + lowestFloor + ".");
		}
	
		else if (curntFloor == destFloor)
		{
			System.out.println("You are already on that floor");
		}
	
		else if (destFloor > curntFloor)
		{
			System.out.println("Going up! Leaving from floor " + curntFloor);
			while (curntFloor <(destFloor-1))
			{
				curntFloor ++;
				System.out.println("Passing Floor " + curntFloor);
			}
			curntFloor ++;
			System.out.println("You have arrived at floor " + curntFloor);
		}
		else if (destFloor < curntFloor)
		{
			System.out.println("Going Down! Leaving from floor " + curntFloor);
			while (curntFloor >(destFloor+1))
			{
				curntFloor --;
				System.out.println("Passing Floor " + curntFloor);
			}
			curntFloor --;
			System.out.println("You have arrived at floor " + curntFloor);
			
		}
		destFloor = curntFloor;
	}//End moveElevator
	
}// End MainClass
