//FILE: Elevator.java
//PROG: Jamie Jones
//Purp: Simulate an elevator moving up and down, 
		//and loading and unloading passengers

package edu.tridenttech.cpt187.jones.program3;

public class Elevator 
{
	//The Class's instance Variables
	private int	numOnBoard;
	private	int	maxCapacity;
	private int	currentFloor;
	private	int	destFloor;
	private	int	maxFloor;
	private	int	minFloor;
	
	public Elevator (int maxRiders, int curntFloor, int highestFloor, int lowestFloor, int curntPass)
	{
		maxCapacity = maxRiders;
		currentFloor = curntFloor;
		maxFloor = highestFloor;
		minFloor = lowestFloor;
		numOnBoard = curntPass;
	}

	public int getNumOnBoard()
	{
		return numOnBoard;
	}

	public int getMaxCapacity()
	{
		return maxCapacity;
	}

	public int	getCurrentFloor()
	{
		return currentFloor;
	}

	public int getDestFloor()
	{
		return destFloor;
	}

	public int getMaxFloor() 
	{
		return maxFloor;
	}

	public int getMinFloor()
	{
		return minFloor;
	}

	public void loadElevator(int numbOn, int maxRiders, int curntPass)
	{
		numOnBoard += numbOn;
		System.out.println("Number of Passengers getting on: " + numbOn);
		
		if (numbOn > maxRiders - curntPass)
		{
			System.out.println("I'm sorry. This elevator has a limit of " + maxRiders + " people. With " 
					+ curntPass + " current passegners, " + numbOn + " is above the maximum for safe travel!");
			numbOn = maxRiders - curntPass;
			System.out.println(numbOn + " will be allowed to ride.");
			curntPass = curntPass + numbOn;
			System.out.println("Total Passengers Boarded: " + curntPass + ".");
		}
		else
		{
			curntPass += numbOn;
			System.out.println("Total Passengers Boarded: " + curntPass + ".");
		}
	}

	public void unLoadElevator (int numbOff, int curntPass)
	{
		numOnBoard -= numbOff;
		if (numbOff <= curntPass)
			{	
				
				System.out.println(numbOff + " passengers exiting elevator");
			}
			else
			{	
				System.out.println(curntPass + " passenger(s) are leaving the elevator");
					
			}
	}
	
	
	
	public void moveElevator (int floor)
	{
		destFloor = floor;
	
	}
	
	
}// End class Elevator